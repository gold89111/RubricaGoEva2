# RubricaGo

MVP académico (DSY1105 – Evaluación Parcial 2) de una aplicación móvil Android para **aplicar rúbricas y registrar evidencias de desempeño durante evaluaciones prácticas**, con enfoque **offline-first**.

> Proyecto con datos 100 % ficticios. No contiene nombres, RUT, correos ni fotografías reales, ni se conecta a sistemas de ninguna organización.

## Integrantes
- Nombre Apellido – Estudiante A
- Nombre Apellido – Estudiante B

**Equipo N° __ · Sección __**

## Problema
Los docentes e instructores evalúan en salas, patios y terrenos con conectividad limitada. El papel obliga a transcribir después y retrasa la retroalimentación. RubricaGo permite evaluar directamente en el teléfono, guardar todo localmente y consolidar más adelante.

## Funcionalidades implementadas
- **Login y registro de evaluador** con validación por campo (íconos y mensajes de error).
- **Actividades** con rúbrica y avance animado de alumnos evaluados.
- **Evaluación por criterios** (puntaje 0–4), cálculo automático de puntaje y nota (1.0–7.0, 60 % exigencia).
- **Retroalimentación** validada (10–300 caracteres).
- **Gestión de alumnos ficticios** (crear / eliminar) con formulario validado.
- **Resumen por grupo**: promedio y avance.
- **Persistencia local con Room** (funciona sin internet). Campo `sincronizada` listo para la futura consolidación vía API REST.
- **Recursos nativos:** 📷 cámara (foto de evidencia, con permiso en tiempo de ejecución y manejo de rechazo) y 📳 vibración (éxito / error).
- **Animaciones:** transiciones de navegación, barras de progreso, cambio animado de color/nota, `AnimatedVisibility`.

## Arquitectura
MVVM + Repository, estado con `StateFlow`/`UiState`. Las validaciones viven en `domain/Validators.kt` (sin dependencias de UI).

```
app/src/main/java/cl/rubricago/app/
├── data/local/        Entities, DAOs, AppDatabase (Room)
├── data/repository/   RubricaRepository
├── domain/            Validators, Calculos (lógica pura, con pruebas unitarias)
├── recursos/          Camara, Haptica (recursos nativos)
├── navigation/        AppNavHost y rutas
├── ui/theme|components|screens   Material 3 + Compose
├── viewmodel/         ViewModels + factory
└── utils/
```

## Tecnologías
Kotlin · Jetpack Compose · Material 3 · Navigation Compose · Room (KSP) · Coil · JUnit.

## Cómo ejecutar
1. Android Studio (Koala o superior) con JDK 17.
2. `File > Open` y seleccionar la carpeta del proyecto; esperar el *Gradle Sync*.
3. Ejecutar en emulador o teléfono Android 8.0+ (API 26+).
4. Usuario de prueba: `evaluador01` / `demo1234` (o crear uno nuevo en *Regístrate*).
5. Pruebas unitarias: `./gradlew test` o clic derecho en `app/src/test` > *Run*.

## Planificación
Tablero de Trello: _(pegar aquí el enlace)_
