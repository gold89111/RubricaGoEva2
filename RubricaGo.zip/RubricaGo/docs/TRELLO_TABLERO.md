# Tablero Trello sugerido (cada tarjeta con responsable y fecha)

Listas: **Backlog · En progreso · En revisión · Hecho**

| Sem | Tarjeta | Responsable |
|---|---|---|
| 6 | Crear repo GitHub público y dar acceso al docente | A |
| 6 | Crear tablero Trello e invitar al docente | B |
| 6 | Proyecto base + tema Material 3 | A |
| 6 | Navegación (NavHost + barra inferior) | B |
| 7 | Login con validaciones (ViewModel) | A |
| 7 | Registro de evaluador con validaciones | B |
| 7 | Formulario de alumno | B |
| 8 | Entidades y DAOs Room | A |
| 8 | Repositorio + datos demo | A |
| 8 | Pantalla de actividades y alumnos | B |
| 9 | Pantalla de evaluación por criterios | B |
| 9 | Cálculo de nota + pruebas unitarias | A |
| 9 | Recurso nativo: cámara + permisos | B |
| 9 | Recurso nativo: vibración | A |
| 10 | Animaciones | B |
| 10 | Resumen por grupo | A |
| 10 | README y revisión final | A + B |
| 11 | Subir ZIP al AVA grupal / activar AVA individual | A y B |
