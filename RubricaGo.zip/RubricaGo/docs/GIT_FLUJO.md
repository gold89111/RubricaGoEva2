# Flujo de Git (ambos deben commitear)

```bash
git init
git branch -M main
git remote add origin <URL_DEL_REPO>
```

Una rama por tarea y *pull request* revisado por el compañero:
`feature/login`, `feature/room`, `feature/evaluacion`, `feature/camara`, `feature/animaciones`

Commits técnicos y descriptivos, ejemplos:
- `chore: configura proyecto base con Compose, Room y Navigation`
- `feat(room): agrega entidades y DAOs de rúbricas y evaluaciones`
- `feat(auth): valida usuario y contraseña en LoginViewModel`
- `feat(evaluacion): calcula puntaje y nota según criterios`
- `feat(camara): solicita permiso y guarda foto de evidencia`
- `test: agrega pruebas unitarias de validadores y cálculo de nota`
- `docs: actualiza README con pasos de ejecución`

⚠️ NO hagan ningún commit ni push después de la fecha de entrega (1.0 automático).
⚠️ No mencionen el nombre real de la institución en commits, README, Trello ni capturas.
