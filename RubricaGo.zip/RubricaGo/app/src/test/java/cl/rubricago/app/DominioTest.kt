package cl.rubricago.app

import cl.rubricago.app.domain.Calculos
import cl.rubricago.app.domain.Validators
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class DominioTest {
    @Test fun usuarioCorto_esInvalido() = assertNotNull(Validators.validarUsuario("ab"))
    @Test fun usuarioValido_noTieneError() = assertNull(Validators.validarUsuario("evaluador01"))
    @Test fun passwordSinNumero_esInvalida() = assertNotNull(Validators.validarPassword("demodemo"))
    @Test fun passwordValida_noTieneError() = assertNull(Validators.validarPassword("demo1234"))
    @Test fun confirmacionDistinta_esInvalida() = assertNotNull(Validators.validarConfirmacion("abc123", "abc124"))
    @Test fun retroCorta_esInvalida() = assertNotNull(Validators.validarRetroalimentacion("corta"))
    @Test fun criteriosIncompletosDanError() = assertNotNull(Validators.validarCriterios(listOf(1, null, 3)))
    @Test fun criteriosCompletos_sinError() = assertNull(Validators.validarCriterios(listOf(1, 2, 3)))

    @Test fun notaMinima() = assertEquals(1.0, Calculos.calcularNota(0, 16), 0.0)
    @Test fun notaMaxima() = assertEquals(7.0, Calculos.calcularNota(16, 16), 0.0)
    @Test fun notaCuatroConSesentaPorCiento() = assertEquals(4.0, Calculos.calcularNota(6, 10), 0.0)
    @Test fun notaIntermedia() = assertEquals(4.2, Calculos.calcularNota(10, 16), 0.0)
}
