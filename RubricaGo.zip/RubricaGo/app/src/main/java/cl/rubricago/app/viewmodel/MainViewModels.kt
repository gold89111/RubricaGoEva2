package cl.rubricago.app.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cl.rubricago.app.SessionManager
import cl.rubricago.app.data.local.ActividadResumen
import cl.rubricago.app.data.local.AlumnoConEstado
import cl.rubricago.app.data.local.AlumnoEntity
import cl.rubricago.app.data.repository.RubricaRepository
import cl.rubricago.app.domain.Calculos
import cl.rubricago.app.domain.ResumenGrupo
import cl.rubricago.app.domain.Validators
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

// ---------------- HOME ----------------
data class HomeUiState(
    val nombreUsuario: String = "",
    val actividades: List<ActividadResumen> = emptyList(),
    val pendientesSync: Int = 0
)

class HomeViewModel(repo: RubricaRepository, private val session: SessionManager) : ViewModel() {
    val ui: StateFlow<HomeUiState> = combine(
        repo.observarResumenActividades(), repo.observarPendientes(), session.nombre
    ) { actividades, pendientes, nombre ->
        HomeUiState(nombre.orEmpty(), actividades, pendientes)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())

    fun cerrarSesion() = session.cerrar()
}

// ---------------- ACTIVIDAD (alumnos con estado) ----------------
data class ActividadUiState(
    val titulo: String = "",
    val alumnos: List<AlumnoConEstado> = emptyList()
) {
    val evaluados: Int get() = alumnos.count { it.nota != null }
    val avance: Float get() = if (alumnos.isEmpty()) 0f else evaluados.toFloat() / alumnos.size
}

class ActividadViewModel(repo: RubricaRepository, handle: SavedStateHandle) : ViewModel() {
    private val rubricaId: Long = checkNotNull(handle.get<Long>("rubricaId"))
    private val titulo = MutableStateFlow("")

    init {
        viewModelScope.launch { titulo.value = repo.tituloActividadDeRubrica(rubricaId) }
    }

    val ui: StateFlow<ActividadUiState> = combine(
        repo.observarAlumnosConEstado(rubricaId), titulo
    ) { alumnos, t -> ActividadUiState(t, alumnos) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ActividadUiState())
}

// ---------------- EVALUACIÓN ----------------
data class CriterioUi(val id: Long, val descripcion: String, val puntajeMax: Int, val puntaje: Int? = null)

data class EvaluacionUiState(
    val cargando: Boolean = true,
    val alumnoNombre: String = "",
    val actividad: String = "",
    val criterios: List<CriterioUi> = emptyList(),
    val retroalimentacion: String = "",
    val retroError: String? = null,
    val criteriosError: String? = null,
    val fotoPath: String? = null,
    val guardando: Boolean = false,
    val guardado: Boolean = false
) {
    val puntajeTotal: Int get() = criterios.sumOf { it.puntaje ?: 0 }
    val puntajeMaximo: Int get() = criterios.sumOf { it.puntajeMax }
    val nota: Double get() = Calculos.calcularNota(puntajeTotal, puntajeMaximo)
}

class EvaluacionViewModel(private val repo: RubricaRepository, handle: SavedStateHandle) : ViewModel() {
    private val alumnoId: Long = checkNotNull(handle.get<Long>("alumnoId"))
    private val rubricaId: Long = checkNotNull(handle.get<Long>("rubricaId"))

    private val _ui = MutableStateFlow(EvaluacionUiState())
    val ui: StateFlow<EvaluacionUiState> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            val d = repo.cargarDatosEvaluacion(alumnoId, rubricaId)
            if (d == null) {
                _ui.update { it.copy(cargando = false) }
                return@launch
            }
            _ui.update {
                it.copy(
                    cargando = false,
                    alumnoNombre = d.alumnoNombre,
                    actividad = d.actividad,
                    criterios = d.criterios.map { c -> CriterioUi(c.id, c.descripcion, c.puntajeMax, d.detallesPrevios[c.id]) },
                    retroalimentacion = d.previa?.retroalimentacion.orEmpty(),
                    fotoPath = d.previa?.fotoPath
                )
            }
        }
    }

    fun onPuntaje(criterioId: Long, puntaje: Int) = _ui.update { s ->
        val nuevos = s.criterios.map { if (it.id == criterioId) it.copy(puntaje = puntaje.coerceIn(0, it.puntajeMax)) else it }
        s.copy(criterios = nuevos, criteriosError = null)
    }

    fun onRetroalimentacion(v: String) = _ui.update { it.copy(retroalimentacion = v, retroError = Validators.validarRetroalimentacion(v)) }
    fun onFoto(path: String) = _ui.update { it.copy(fotoPath = path) }
    fun onQuitarFoto() = _ui.update { it.copy(fotoPath = null) }

    /** @return false si hay errores de validación (la pantalla vibra); true si se inició el guardado. */
    fun guardar(): Boolean {
        val s = _ui.value
        val eCriterios = Validators.validarCriterios(s.criterios.map { it.puntaje })
        val eRetro = Validators.validarRetroalimentacion(s.retroalimentacion)
        if (eCriterios != null || eRetro != null) {
            _ui.update { it.copy(criteriosError = eCriterios, retroError = eRetro) }
            return false
        }
        viewModelScope.launch {
            _ui.update { it.copy(guardando = true) }
            repo.guardarEvaluacion(
                alumnoId, rubricaId,
                s.criterios.associate { it.id to (it.puntaje ?: 0) },
                s.puntajeMaximo, s.retroalimentacion, s.fotoPath
            )
            _ui.update { it.copy(guardando = false, guardado = true) }
        }
        return true
    }
}

// ---------------- ALUMNOS ----------------
class AlumnosViewModel(private val repo: RubricaRepository) : ViewModel() {
    val alumnos: StateFlow<List<AlumnoEntity>> = repo.observarAlumnos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun eliminar(alumno: AlumnoEntity) {
        viewModelScope.launch { repo.eliminarAlumno(alumno) }
    }
}

data class AlumnoFormUiState(
    val nombre: String = "",
    val grupo: String = "",
    val nombreError: String? = null,
    val grupoError: String? = null,
    val errorGeneral: String? = null,
    val exito: Boolean = false
)

class AlumnoFormViewModel(private val repo: RubricaRepository) : ViewModel() {
    private val _ui = MutableStateFlow(AlumnoFormUiState())
    val ui: StateFlow<AlumnoFormUiState> = _ui.asStateFlow()

    fun onNombreChange(v: String) = _ui.update { it.copy(nombre = v, nombreError = Validators.validarNombre(v), errorGeneral = null) }
    fun onGrupoChange(v: String) = _ui.update { it.copy(grupo = v, grupoError = Validators.validarGrupo(v), errorGeneral = null) }

    fun guardar() {
        val s = _ui.value
        val eN = Validators.validarNombre(s.nombre)
        val eG = Validators.validarGrupo(s.grupo)
        if (eN != null || eG != null) {
            _ui.update { it.copy(nombreError = eN, grupoError = eG) }
            return
        }
        viewModelScope.launch {
            val ok = repo.guardarAlumno(s.nombre, s.grupo)
            if (ok) _ui.update { it.copy(exito = true) }
            else _ui.update { it.copy(nombreError = "Ya existe un alumno con ese nombre") }
        }
    }
}

// ---------------- RESUMEN ----------------
data class ResumenUiState(val grupos: List<ResumenGrupo> = emptyList(), val pendientesSync: Int = 0)

class ResumenViewModel(repo: RubricaRepository) : ViewModel() {
    val ui: StateFlow<ResumenUiState> = combine(
        repo.observarAlumnos(), repo.observarEvaluaciones(), repo.observarResumenActividades(), repo.observarPendientes()
    ) { alumnos, evaluaciones, actividades, pendientes ->
        ResumenUiState(Calculos.resumenPorGrupo(alumnos, evaluaciones, actividades.size), pendientes)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ResumenUiState())
}
