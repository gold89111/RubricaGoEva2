package cl.rubricago.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import cl.rubricago.app.navigation.AppNavHost
import cl.rubricago.app.ui.theme.RubricaGoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RubricaGoTheme { AppNavHost() } }
    }
}
