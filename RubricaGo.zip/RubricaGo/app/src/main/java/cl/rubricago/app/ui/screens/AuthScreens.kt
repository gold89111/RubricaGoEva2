package cl.rubricago.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cl.rubricago.app.recursos.Haptica
import cl.rubricago.app.ui.components.BotonPrincipal
import cl.rubricago.app.ui.components.CampoTexto
import cl.rubricago.app.viewmodel.LoginViewModel
import cl.rubricago.app.viewmodel.RegisterViewModel

@Composable
fun LoginScreen(vm: LoginViewModel, onLoginOk: () -> Unit, onRegistro: () -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(ui.exito) {
        if (ui.exito) {
            Haptica.exito(context)
            onLoginOk()
        }
    }
    LaunchedEffect(ui.errorGeneral) { if (ui.errorGeneral != null) Haptica.error(context) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Spacer(Modifier.height(48.dp))
        Icon(Icons.Filled.School, contentDescription = null, modifier = Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
        Text("RubricaGo", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Evaluación práctica en terreno", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))

        CampoTexto(ui.usuario, vm::onUsuarioChange, "Usuario", Icons.Filled.Person, error = ui.usuarioError)
        CampoTexto(
            ui.password, vm::onPasswordChange, "Contraseña", Icons.Filled.Lock,
            error = ui.passwordError, esPassword = true, imeAction = ImeAction.Done
        )

        AnimatedVisibility(visible = ui.errorGeneral != null) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer), modifier = Modifier.fillMaxWidth()) {
                Text(ui.errorGeneral.orEmpty(), modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }

        Spacer(Modifier.height(8.dp))
        BotonPrincipal("Ingresar", onClick = vm::onLogin, cargando = ui.cargando)
        TextButton(onClick = onRegistro) { Text("¿No tienes cuenta? Regístrate") }
        Text("Cuenta de prueba: evaluador01 / demo1234", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(vm: RegisterViewModel, onVolver: () -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(ui.exito) {
        if (ui.exito) {
            Haptica.exito(context)
            onVolver()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Crear cuenta de evaluador") },
                navigationIcon = { IconButton(onClick = onVolver) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Usa un nombre ficticio. No ingreses datos reales.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            CampoTexto(ui.nombre, vm::onNombreChange, "Nombre", Icons.Filled.Badge, error = ui.nombreError)
            CampoTexto(ui.usuario, vm::onUsuarioChange, "Usuario", Icons.Filled.Person, error = ui.usuarioError, ayuda = "Letras, números, punto o guion bajo")
            CampoTexto(ui.password, vm::onPasswordChange, "Contraseña", Icons.Filled.Lock, error = ui.passwordError, esPassword = true, ayuda = "Mínimo 6 caracteres, con letras y números")
            CampoTexto(ui.confirmacion, vm::onConfirmacionChange, "Confirmar contraseña", Icons.Filled.Lock, error = ui.confirmacionError, esPassword = true, imeAction = ImeAction.Done)
            Spacer(Modifier.height(8.dp))
            BotonPrincipal("Crear cuenta", onClick = vm::onRegistrar, cargando = ui.cargando)
        }
    }
}
