package cl.rubricago.app.viewmodel

import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import cl.rubricago.app.RubricaApp

private fun CreationExtras.app(): RubricaApp = this[APPLICATION_KEY] as RubricaApp

object AppViewModelProvider {
    val Factory = viewModelFactory {
        initializer { LoginViewModel(app().container.repository, app().container.session) }
        initializer { RegisterViewModel(app().container.repository) }
        initializer { HomeViewModel(app().container.repository, app().container.session) }
        initializer { ActividadViewModel(app().container.repository, createSavedStateHandle()) }
        initializer { EvaluacionViewModel(app().container.repository, createSavedStateHandle()) }
        initializer { AlumnosViewModel(app().container.repository) }
        initializer { AlumnoFormViewModel(app().container.repository) }
        initializer { ResumenViewModel(app().container.repository) }
    }
}
