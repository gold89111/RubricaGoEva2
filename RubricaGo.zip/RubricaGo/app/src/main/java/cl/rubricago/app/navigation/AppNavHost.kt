package cl.rubricago.app.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import cl.rubricago.app.ui.screens.ActividadScreen
import cl.rubricago.app.ui.screens.AlumnoFormScreen
import cl.rubricago.app.ui.screens.AlumnosScreen
import cl.rubricago.app.ui.screens.EvaluacionScreen
import cl.rubricago.app.ui.screens.HomeScreen
import cl.rubricago.app.ui.screens.LoginScreen
import cl.rubricago.app.ui.screens.RegisterScreen
import cl.rubricago.app.ui.screens.ResumenScreen
import cl.rubricago.app.viewmodel.ActividadViewModel
import cl.rubricago.app.viewmodel.AlumnoFormViewModel
import cl.rubricago.app.viewmodel.AlumnosViewModel
import cl.rubricago.app.viewmodel.AppViewModelProvider
import cl.rubricago.app.viewmodel.EvaluacionViewModel
import cl.rubricago.app.viewmodel.HomeViewModel
import cl.rubricago.app.viewmodel.LoginViewModel
import cl.rubricago.app.viewmodel.RegisterViewModel
import cl.rubricago.app.viewmodel.ResumenViewModel

object Rutas {
    const val LOGIN = "login"
    const val REGISTRO = "registro"
    const val HOME = "home"
    const val ALUMNOS = "alumnos"
    const val ALUMNO_FORM = "alumno_form"
    const val RESUMEN = "resumen"
    const val ACTIVIDAD = "actividad/{rubricaId}"
    const val EVALUAR = "evaluar/{alumnoId}/{rubricaId}"

    fun actividad(rubricaId: Long) = "actividad/$rubricaId"
    fun evaluar(alumnoId: Long, rubricaId: Long) = "evaluar/$alumnoId/$rubricaId"
}

private data class Tab(val ruta: String, val titulo: String, val icono: ImageVector)

@Composable
fun AppNavHost() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val rutaActual = backStack?.destination?.route

    val tabs = listOf(
        Tab(Rutas.HOME, "Actividades", Icons.Filled.Home),
        Tab(Rutas.ALUMNOS, "Alumnos", Icons.Filled.Group),
        Tab(Rutas.RESUMEN, "Resumen", Icons.Filled.BarChart)
    )

    Scaffold(
        bottomBar = {
            AnimatedVisibility(
                visible = tabs.any { it.ruta == rutaActual },
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut()
            ) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = rutaActual == tab.ruta,
                            onClick = {
                                nav.navigate(tab.ruta) {
                                    popUpTo(Rutas.HOME) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icono, contentDescription = tab.titulo) },
                            label = { Text(tab.titulo) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Rutas.LOGIN,
            modifier = Modifier.padding(padding),
            enterTransition = { fadeIn(tween(300)) + slideInHorizontally(tween(300)) { it / 6 } },
            exitTransition = { fadeOut(tween(200)) },
            popEnterTransition = { fadeIn(tween(300)) },
            popExitTransition = { fadeOut(tween(200)) + slideOutHorizontally(tween(300)) { it / 6 } }
        ) {
            composable(Rutas.LOGIN) {
                val vm: LoginViewModel = viewModel(factory = AppViewModelProvider.Factory)
                LoginScreen(
                    vm = vm,
                    onLoginOk = { nav.navigate(Rutas.HOME) { popUpTo(Rutas.LOGIN) { inclusive = true } } },
                    onRegistro = { nav.navigate(Rutas.REGISTRO) }
                )
            }
            composable(Rutas.REGISTRO) {
                val vm: RegisterViewModel = viewModel(factory = AppViewModelProvider.Factory)
                RegisterScreen(vm = vm, onVolver = { nav.popBackStack() })
            }
            composable(Rutas.HOME) {
                val vm: HomeViewModel = viewModel(factory = AppViewModelProvider.Factory)
                HomeScreen(
                    vm = vm,
                    onActividad = { nav.navigate(Rutas.actividad(it)) },
                    onCerrarSesion = {
                        vm.cerrarSesion()
                        nav.navigate(Rutas.LOGIN) { popUpTo(Rutas.HOME) { inclusive = true } }
                    }
                )
            }
            composable(
                route = Rutas.ACTIVIDAD,
                arguments = listOf(navArgument("rubricaId") { type = NavType.LongType })
            ) { entry ->
                val rubricaId = entry.arguments?.getLong("rubricaId") ?: 0L
                val vm: ActividadViewModel = viewModel(factory = AppViewModelProvider.Factory)
                ActividadScreen(
                    vm = vm,
                    onVolver = { nav.popBackStack() },
                    onEvaluar = { alumnoId -> nav.navigate(Rutas.evaluar(alumnoId, rubricaId)) }
                )
            }
            composable(
                route = Rutas.EVALUAR,
                arguments = listOf(
                    navArgument("alumnoId") { type = NavType.LongType },
                    navArgument("rubricaId") { type = NavType.LongType }
                )
            ) {
                val vm: EvaluacionViewModel = viewModel(factory = AppViewModelProvider.Factory)
                EvaluacionScreen(vm = vm, onVolver = { nav.popBackStack() })
            }
            composable(Rutas.ALUMNOS) {
                val vm: AlumnosViewModel = viewModel(factory = AppViewModelProvider.Factory)
                AlumnosScreen(vm = vm, onNuevo = { nav.navigate(Rutas.ALUMNO_FORM) })
            }
            composable(Rutas.ALUMNO_FORM) {
                val vm: AlumnoFormViewModel = viewModel(factory = AppViewModelProvider.Factory)
                AlumnoFormScreen(vm = vm, onVolver = { nav.popBackStack() })
            }
            composable(Rutas.RESUMEN) {
                val vm: ResumenViewModel = viewModel(factory = AppViewModelProvider.Factory)
                ResumenScreen(vm = vm)
            }
        }
    }
}
