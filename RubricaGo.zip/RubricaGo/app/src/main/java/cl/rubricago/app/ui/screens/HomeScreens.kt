package cl.rubricago.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.animation.animateColorAsState
import cl.rubricago.app.data.local.AlumnoConEstado
import cl.rubricago.app.ui.components.BarraProgreso
import cl.rubricago.app.ui.components.EstadoVacio
import cl.rubricago.app.ui.theme.VerdeOk
import cl.rubricago.app.utils.formatoNota
import cl.rubricago.app.viewmodel.ActividadViewModel
import cl.rubricago.app.viewmodel.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: HomeViewModel, onActividad: (Long) -> Unit, onCerrarSesion: () -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Actividades") },
                actions = {
                    IconButton(onClick = onCerrarSesion) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Cerrar sesión")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                    Text("Hola, ${ui.nombreUsuario}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Selecciona una actividad práctica para evaluar", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                AnimatedVisibility(visible = ui.pendientesSync > 0) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.CloudOff, contentDescription = null)
                            Text(
                                "  ${ui.pendientesSync} evaluación(es) guardadas en el teléfono, pendientes de sincronizar",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
            if (ui.actividades.isEmpty()) {
                item { Text("Cargando actividades…", color = MaterialTheme.colorScheme.outline) }
            }
            items(ui.actividades, key = { it.rubricaId }) { a ->
                Card(modifier = Modifier.fillMaxWidth().clickable { onActividad(a.rubricaId) }) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(a.nombre, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text(a.area, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                        }
                        BarraProgreso(if (a.totalAlumnos == 0) 0f else a.evaluados.toFloat() / a.totalAlumnos)
                        Text("${a.evaluados} de ${a.totalAlumnos} alumnos evaluados", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActividadScreen(vm: ActividadViewModel, onVolver: () -> Unit, onEvaluar: (alumnoId: Long) -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(ui.titulo) },
                navigationIcon = { IconButton(onClick = onVolver) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver") } }
            )
        }
    ) { padding ->
        if (ui.alumnos.isEmpty()) {
            EstadoVacio(Icons.Filled.Group, "No hay alumnos. Agrégalos en la pestaña Alumnos.", Modifier.padding(padding))
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        BarraProgreso(ui.avance)
                        Text("${ui.evaluados} de ${ui.alumnos.size} evaluados", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(4.dp))
                    }
                }
                items(ui.alumnos, key = { it.alumnoId }) { al ->
                    AlumnoFila(al, onClick = { onEvaluar(al.alumnoId) })
                }
            }
        }
    }
}

@Composable
private fun AlumnoFila(al: AlumnoConEstado, onClick: () -> Unit) {
    val evaluado = al.nota != null
    val colorEstado by animateColorAsState(
        targetValue = when {
            !evaluado -> MaterialTheme.colorScheme.surfaceVariant
            al.nota!! >= 4.0 -> VerdeOk.copy(alpha = 0.18f)
            else -> MaterialTheme.colorScheme.error.copy(alpha = 0.18f)
        },
        label = "colorEstado"
    )
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(al.nombre, style = MaterialTheme.typography.titleMedium)
                Text("Grupo ${al.grupo}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Card(colors = CardDefaults.cardColors(containerColor = colorEstado)) {
                Text(
                    if (evaluado) "Nota ${al.nota!!.formatoNota()}" else "Pendiente",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.labelLarge
                )
            }
            Spacer(Modifier.size(4.dp))
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
        }
    }
}
