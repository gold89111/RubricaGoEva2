package cl.rubricago.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cl.rubricago.app.domain.Calculos
import cl.rubricago.app.recursos.Camara
import cl.rubricago.app.recursos.Haptica
import cl.rubricago.app.ui.components.BotonPrincipal
import cl.rubricago.app.ui.components.CampoTexto
import cl.rubricago.app.ui.theme.colorNota
import cl.rubricago.app.utils.formatoNota
import cl.rubricago.app.viewmodel.CriterioUi
import cl.rubricago.app.viewmodel.EvaluacionViewModel
import coil.compose.AsyncImage
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EvaluacionScreen(vm: EvaluacionViewModel, onVolver: () -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var permisoDenegado by remember { mutableStateOf(false) }
    var rutaPendiente by rememberSaveable { mutableStateOf<String?>(null) }

    // --- Recurso nativo: cámara ---
    val tomarFoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val ruta = rutaPendiente
        if (ok && ruta != null) vm.onFoto(ruta) else ruta?.let { File(it).delete() }
        rutaPendiente = null
    }
    fun abrirCamara() {
        val archivo = Camara.crearArchivo(context)
        rutaPendiente = archivo.absolutePath
        tomarFoto.launch(Camara.uriPara(context, archivo))
    }
    val pedirPermiso = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { concedido ->
        permisoDenegado = !concedido
        if (concedido) abrirCamara()
    }

    // --- Recurso nativo: vibración al guardar ---
    LaunchedEffect(ui.guardado) {
        if (ui.guardado) {
            Haptica.exito(context)
            onVolver()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(ui.alumnoNombre.ifEmpty { "Evaluación" }) },
                navigationIcon = { IconButton(onClick = onVolver) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver") } }
            )
        }
    ) { padding ->
        if (ui.cargando) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(ui.actividad, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Puntaje por criterio: 0 = no logrado · 4 = logro total", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            items(ui.criterios, key = { it.id }) { c ->
                CriterioCard(c, onSeleccion = { vm.onPuntaje(c.id, it) })
            }

            item {
                AnimatedVisibility(visible = ui.criteriosError != null) {
                    Text(ui.criteriosError.orEmpty(), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
            }

            item { ResumenNota(ui.puntajeTotal, ui.puntajeMaximo, ui.nota) }

            item {
                CampoTexto(
                    valor = ui.retroalimentacion, onCambio = vm::onRetroalimentacion,
                    etiqueta = "Retroalimentación", icono = Icons.Filled.Edit,
                    error = ui.retroError, unaLinea = false, minLineas = 3,
                    ayuda = "${ui.retroalimentacion.length}/300"
                )
            }

            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Evidencia fotográfica (opcional)", style = MaterialTheme.typography.titleSmall)
                        Text("Usa solo material ficticio. No fotografíes personas reales.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(onClick = {
                            val tienePermiso = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            if (tienePermiso) abrirCamara() else pedirPermiso.launch(Manifest.permission.CAMERA)
                        }) {
                            Icon(Icons.Filled.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(8.dp))
                            Text(if (ui.fotoPath == null) "Tomar foto" else "Reemplazar foto")
                        }
                        AnimatedVisibility(visible = permisoDenegado) {
                            Column {
                                Text("Sin permiso de cámara no se puede adjuntar evidencia. Puedes activarlo en Ajustes.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = {
                                    context.startActivity(
                                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                                    )
                                }) { Text("Abrir ajustes") }
                            }
                        }
                        AnimatedVisibility(visible = ui.fotoPath != null) {
                            Column {
                                AsyncImage(
                                    model = File(ui.fotoPath.orEmpty()),
                                    contentDescription = "Evidencia fotográfica",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(12.dp))
                                )
                                TextButton(onClick = vm::onQuitarFoto) { Text("Quitar foto") }
                            }
                        }
                    }
                }
            }

            item {
                BotonPrincipal(
                    texto = "Guardar evaluación",
                    onClick = { if (!vm.guardar()) Haptica.error(context) },
                    cargando = ui.guardando
                )
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun CriterioCard(c: CriterioUi, onSeleccion: (Int) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(c.descripcion, style = MaterialTheme.typography.bodyLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (0..c.puntajeMax).forEach { n ->
                    FilterChip(
                        selected = c.puntaje == n,
                        onClick = { onSeleccion(n) },
                        label = { Text("$n") },
                        leadingIcon = if (c.puntaje == n) {
                            { Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(FilterChipDefaults.IconSize)) }
                        } else null
                    )
                }
            }
        }
    }
}

@Composable
private fun ResumenNota(total: Int, maximo: Int, nota: Double) {
    val colorAnimado by animateColorAsState(colorNota(nota), label = "colorNota")
    val notaAnimada by animateFloatAsState(nota.toFloat(), label = "notaAnimada")
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Puntaje: $total / $maximo", style = MaterialTheme.typography.titleMedium)
                Text(Calculos.nivelDesempeno(nota), style = MaterialTheme.typography.bodyMedium)
            }
            Text(
                notaAnimada.toDouble().formatoNota(),
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold,
                color = colorAnimado
            )
        }
    }
}
