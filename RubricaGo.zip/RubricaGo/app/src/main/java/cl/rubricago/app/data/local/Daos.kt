package cl.rubricago.app.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

data class ActividadResumen(
    val actividadId: Long,
    val nombre: String,
    val area: String,
    val rubricaId: Long,
    val evaluados: Int,
    val totalAlumnos: Int
)

data class AlumnoConEstado(
    val alumnoId: Long,
    val nombre: String,
    val grupo: String,
    val puntajeTotal: Int?,
    val puntajeMaximo: Int?,
    val nota: Double?
)

@Dao
interface UsuarioDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertar(usuario: UsuarioEntity): Long

    @Query("SELECT * FROM usuarios WHERE usuario = :usuario LIMIT 1")
    suspend fun buscar(usuario: String): UsuarioEntity?

    @Query("SELECT COUNT(*) FROM usuarios")
    suspend fun contar(): Int
}

@Dao
interface CatalogoDao {
    @Insert suspend fun insertarActividad(a: ActividadEntity): Long
    @Insert suspend fun insertarRubrica(r: RubricaEntity): Long
    @Insert suspend fun insertarCriterios(c: List<CriterioEntity>)

    @Query("SELECT COUNT(*) FROM actividades")
    suspend fun contarActividades(): Int

    @Query("SELECT * FROM rubricas WHERE id = :id")
    suspend fun rubrica(id: Long): RubricaEntity?

    @Query("SELECT * FROM actividades WHERE id = :id")
    suspend fun actividad(id: Long): ActividadEntity?

    @Query("SELECT * FROM criterios WHERE rubricaId = :rubricaId ORDER BY id")
    suspend fun criterios(rubricaId: Long): List<CriterioEntity>

    @Query(
        """SELECT a.id AS actividadId, a.nombre AS nombre, a.area AS area, r.id AS rubricaId,
           (SELECT COUNT(*) FROM evaluaciones e WHERE e.rubricaId = r.id) AS evaluados,
           (SELECT COUNT(*) FROM alumnos) AS totalAlumnos
           FROM actividades a INNER JOIN rubricas r ON r.actividadId = a.id
           ORDER BY a.nombre"""
    )
    fun observarResumenActividades(): Flow<List<ActividadResumen>>
}

@Dao
interface AlumnoDao {
    @Insert suspend fun insertar(a: AlumnoEntity): Long
    @Delete suspend fun eliminar(a: AlumnoEntity)

    @Query("SELECT * FROM alumnos ORDER BY grupo, nombre")
    fun observarTodos(): Flow<List<AlumnoEntity>>

    @Query("SELECT * FROM alumnos WHERE id = :id")
    suspend fun buscar(id: Long): AlumnoEntity?

    @Query("SELECT COUNT(*) FROM alumnos")
    suspend fun contar(): Int

    @Query("SELECT COUNT(*) FROM alumnos WHERE nombre = :nombre COLLATE NOCASE")
    suspend fun contarPorNombre(nombre: String): Int

    @Query(
        """SELECT al.id AS alumnoId, al.nombre AS nombre, al.grupo AS grupo,
           ev.puntajeTotal AS puntajeTotal, ev.puntajeMaximo AS puntajeMaximo, ev.nota AS nota
           FROM alumnos al
           LEFT JOIN evaluaciones ev ON ev.alumnoId = al.id AND ev.rubricaId = :rubricaId
           ORDER BY al.grupo, al.nombre"""
    )
    fun observarAlumnosConEstado(rubricaId: Long): Flow<List<AlumnoConEstado>>
}

@Dao
abstract class EvaluacionDao {
    @Insert abstract suspend fun insertarEvaluacion(e: EvaluacionEntity): Long
    @Insert abstract suspend fun insertarDetalles(d: List<DetalleEvaluacionEntity>)

    @Query("DELETE FROM evaluaciones WHERE alumnoId = :alumnoId AND rubricaId = :rubricaId")
    abstract suspend fun eliminarPrevia(alumnoId: Long, rubricaId: Long)

    @Query("SELECT * FROM evaluaciones WHERE alumnoId = :alumnoId AND rubricaId = :rubricaId LIMIT 1")
    abstract suspend fun evaluacion(alumnoId: Long, rubricaId: Long): EvaluacionEntity?

    @Query("SELECT * FROM detalles_evaluacion WHERE evaluacionId = :evaluacionId")
    abstract suspend fun detalles(evaluacionId: Long): List<DetalleEvaluacionEntity>

    @Query("SELECT * FROM evaluaciones")
    abstract fun observarTodas(): Flow<List<EvaluacionEntity>>

    @Query("SELECT COUNT(*) FROM evaluaciones WHERE sincronizada = 0")
    abstract fun observarPendientes(): Flow<Int>

    @Transaction
    open suspend fun guardar(e: EvaluacionEntity, detalles: List<DetalleEvaluacionEntity>) {
        eliminarPrevia(e.alumnoId, e.rubricaId)
        val id = insertarEvaluacion(e)
        insertarDetalles(detalles.map { it.copy(evaluacionId = id) })
    }
}
