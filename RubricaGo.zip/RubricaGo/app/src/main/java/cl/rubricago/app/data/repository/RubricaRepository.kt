package cl.rubricago.app.data.repository

import cl.rubricago.app.data.local.*
import cl.rubricago.app.domain.Calculos
import cl.rubricago.app.utils.Seguridad
import kotlinx.coroutines.flow.Flow

data class DatosEvaluacion(
    val alumnoNombre: String,
    val actividad: String,
    val criterios: List<CriterioEntity>,
    val previa: EvaluacionEntity?,
    val detallesPrevios: Map<Long, Int>
)

/** Única puerta de acceso a los datos. Hoy solo Room (offline-first); mañana se le agrega Retrofit. */
class RubricaRepository(db: AppDatabase) {
    private val usuarios = db.usuarioDao()
    private val catalogo = db.catalogoDao()
    private val alumnos = db.alumnoDao()
    private val evaluaciones = db.evaluacionDao()

    // ---- Usuarios ----
    suspend fun autenticar(usuario: String, password: String): UsuarioEntity? {
        val u = usuarios.buscar(usuario.trim().lowercase()) ?: return null
        return if (u.passwordHash == Seguridad.sha256(password)) u else null
    }

    /** @return false si el usuario ya existe */
    suspend fun registrarUsuario(nombre: String, usuario: String, password: String): Boolean {
        val user = usuario.trim().lowercase()
        if (usuarios.buscar(user) != null) return false
        usuarios.insertar(UsuarioEntity(nombre = nombre.trim(), usuario = user, passwordHash = Seguridad.sha256(password)))
        return true
    }

    // ---- Alumnos ----
    fun observarAlumnos(): Flow<List<AlumnoEntity>> = alumnos.observarTodos()
    fun observarAlumnosConEstado(rubricaId: Long) = alumnos.observarAlumnosConEstado(rubricaId)

    /** @return false si ya existe un alumno con ese nombre */
    suspend fun guardarAlumno(nombre: String, grupo: String): Boolean {
        if (alumnos.contarPorNombre(nombre.trim()) > 0) return false
        alumnos.insertar(AlumnoEntity(nombre = nombre.trim(), grupo = grupo.trim().uppercase()))
        return true
    }

    suspend fun eliminarAlumno(a: AlumnoEntity) = alumnos.eliminar(a)

    // ---- Actividades / evaluaciones ----
    fun observarResumenActividades() = catalogo.observarResumenActividades()
    fun observarEvaluaciones() = evaluaciones.observarTodas()
    fun observarPendientes() = evaluaciones.observarPendientes()

    suspend fun tituloActividadDeRubrica(rubricaId: Long): String {
        val r = catalogo.rubrica(rubricaId) ?: return ""
        return catalogo.actividad(r.actividadId)?.nombre.orEmpty()
    }

    suspend fun cargarDatosEvaluacion(alumnoId: Long, rubricaId: Long): DatosEvaluacion? {
        val alumno = alumnos.buscar(alumnoId) ?: return null
        val rubrica = catalogo.rubrica(rubricaId) ?: return null
        val actividad = catalogo.actividad(rubrica.actividadId)?.nombre.orEmpty()
        val previa = evaluaciones.evaluacion(alumnoId, rubricaId)
        val detalles = previa?.let { evaluaciones.detalles(it.id) }.orEmpty().associate { it.criterioId to it.puntaje }
        return DatosEvaluacion(alumno.nombre, actividad, catalogo.criterios(rubricaId), previa, detalles)
    }

    suspend fun guardarEvaluacion(
        alumnoId: Long, rubricaId: Long, puntajes: Map<Long, Int>,
        puntajeMaximo: Int, retroalimentacion: String, fotoPath: String?
    ) {
        val total = puntajes.values.sum()
        val evaluacion = EvaluacionEntity(
            alumnoId = alumnoId, rubricaId = rubricaId, puntajeTotal = total, puntajeMaximo = puntajeMaximo,
            nota = Calculos.calcularNota(total, puntajeMaximo), retroalimentacion = retroalimentacion.trim(),
            fotoPath = fotoPath, fecha = System.currentTimeMillis(), sincronizada = false
        )
        evaluaciones.guardar(evaluacion, puntajes.map { DetalleEvaluacionEntity(evaluacionId = 0, criterioId = it.key, puntaje = it.value) })
    }

    // ---- Datos ficticios de prueba ----
    suspend fun sembrarDatosDemo() {
        if (usuarios.contar() == 0) registrarUsuario("Evaluador Demo", "evaluador01", "demo1234")

        if (catalogo.contarActividades() == 0) {
            val datos = listOf(
                Triple("Primeros auxilios básicos", "Salud y seguridad", listOf(
                    "Evalúa la seguridad de la escena", "Verifica el estado de conciencia",
                    "Aplica la técnica de forma correcta", "Comunica con claridad al equipo")),
                Triple("Comunicación radial", "Comunicaciones", listOf(
                    "Usa el protocolo de llamada", "Emplea vocabulario claro y breve",
                    "Confirma la recepción de mensajes", "Mantiene la calma y el orden")),
                Triple("Evacuación en espacio cerrado", "Simulaciones", listOf(
                    "Planifica la ruta de salida", "Coordina al grupo",
                    "Controla los tiempos", "Verifica el conteo final"))
            )
            datos.forEach { (nombre, area, criterios) ->
                val aId = catalogo.insertarActividad(ActividadEntity(nombre = nombre, area = area))
                val rId = catalogo.insertarRubrica(RubricaEntity(actividadId = aId, nombre = "Rúbrica $nombre"))
                catalogo.insertarCriterios(criterios.map { CriterioEntity(rubricaId = rId, descripcion = it, puntajeMax = 4) })
            }
        }

        if (alumnos.contar() == 0) {
            listOf("A", "A", "A", "B", "B", "B").forEachIndexed { i, g ->
                alumnos.insertar(AlumnoEntity(nombre = "Alumno 0${i + 1}", grupo = g))
            }
        }
    }
}
