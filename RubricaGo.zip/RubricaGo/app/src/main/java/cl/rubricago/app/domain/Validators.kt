package cl.rubricago.app.domain

/** Reglas de validación puras (sin Android ni Compose): la UI solo muestra el mensaje que devuelven. null = válido. */
object Validators {
    private val regexUsuario = Regex("^[a-zA-Z0-9._]+$")
    private val regexNombre = Regex("^[\\p{L}0-9 .'-]+$")
    private val regexGrupo = Regex("^[A-Za-z0-9]{1,5}$")

    fun validarUsuario(u: String): String? = when {
        u.isBlank() -> "El usuario es obligatorio"
        u.length < 4 -> "Mínimo 4 caracteres"
        u.length > 20 -> "Máximo 20 caracteres"
        !regexUsuario.matches(u) -> "Solo letras, números, punto y guion bajo"
        else -> null
    }

    fun validarPassword(p: String): String? = when {
        p.isBlank() -> "La contraseña es obligatoria"
        p.length < 6 -> "Mínimo 6 caracteres"
        p.none { it.isDigit() } -> "Debe incluir al menos un número"
        p.none { it.isLetter() } -> "Debe incluir al menos una letra"
        else -> null
    }

    fun validarConfirmacion(p: String, c: String): String? = when {
        c.isBlank() -> "Confirma tu contraseña"
        p != c -> "Las contraseñas no coinciden"
        else -> null
    }

    fun validarNombre(n: String): String? = when {
        n.isBlank() -> "El nombre es obligatorio"
        n.trim().length < 3 -> "Mínimo 3 caracteres"
        n.length > 40 -> "Máximo 40 caracteres"
        !regexNombre.matches(n.trim()) -> "Contiene caracteres no permitidos"
        else -> null
    }

    fun validarGrupo(g: String): String? = when {
        g.isBlank() -> "El grupo es obligatorio"
        !regexGrupo.matches(g.trim()) -> "Use 1 a 5 letras o números (ej: A, B2)"
        else -> null
    }

    fun validarRetroalimentacion(t: String): String? = when {
        t.isBlank() -> "La retroalimentación es obligatoria"
        t.trim().length < 10 -> "Escribe al menos 10 caracteres"
        t.length > 300 -> "Máximo 300 caracteres"
        else -> null
    }

    fun validarCriterios(puntajes: List<Int?>): String? {
        val faltan = puntajes.count { it == null }
        return if (faltan > 0) "Faltan $faltan criterio(s) por evaluar" else null
    }
}
