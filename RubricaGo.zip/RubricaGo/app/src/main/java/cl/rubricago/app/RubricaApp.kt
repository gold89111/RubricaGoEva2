package cl.rubricago.app

import android.app.Application
import android.content.Context
import cl.rubricago.app.data.local.AppDatabase
import cl.rubricago.app.data.repository.RubricaRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SessionManager {
    private val _nombre = MutableStateFlow<String?>(null)
    val nombre: StateFlow<String?> = _nombre.asStateFlow()
    fun iniciar(nombre: String) { _nombre.value = nombre }
    fun cerrar() { _nombre.value = null }
}

class AppContainer(context: Context) {
    val repository = RubricaRepository(AppDatabase.obtener(context))
    val session = SessionManager()

    init {
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch { repository.sembrarDatosDemo() }
    }
}

class RubricaApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
