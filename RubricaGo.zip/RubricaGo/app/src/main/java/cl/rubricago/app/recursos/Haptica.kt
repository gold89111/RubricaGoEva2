package cl.rubricago.app.recursos

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Recurso nativo 2: vibración (retroalimentación háptica de éxito / error). */
object Haptica {
    @Suppress("DEPRECATION")
    private fun vibrador(context: Context): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    fun exito(context: Context) {
        val v = vibrador(context) ?: return
        if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    fun error(context: Context) {
        val v = vibrador(context) ?: return
        if (v.hasVibrator()) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 60, 60, 60), -1))
    }
}
