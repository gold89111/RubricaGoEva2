package cl.rubricago.app.utils

import java.security.MessageDigest
import java.util.Locale

object Seguridad {
    fun sha256(texto: String): String =
        MessageDigest.getInstance("SHA-256").digest(texto.toByteArray()).joinToString("") { "%02x".format(it) }
}

fun Double.formatoNota(): String = String.format(Locale("es", "CL"), "%.1f", this)
