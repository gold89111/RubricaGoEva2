package cl.rubricago.app.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "usuarios", indices = [Index(value = ["usuario"], unique = true)])
data class UsuarioEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val usuario: String,
    val passwordHash: String
)

@Entity(tableName = "actividades")
data class ActividadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val area: String
)

@Entity(
    tableName = "rubricas",
    foreignKeys = [ForeignKey(entity = ActividadEntity::class, parentColumns = ["id"], childColumns = ["actividadId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("actividadId")]
)
data class RubricaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val actividadId: Long,
    val nombre: String
)

@Entity(
    tableName = "criterios",
    foreignKeys = [ForeignKey(entity = RubricaEntity::class, parentColumns = ["id"], childColumns = ["rubricaId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("rubricaId")]
)
data class CriterioEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val rubricaId: Long,
    val descripcion: String,
    val puntajeMax: Int
)

@Entity(tableName = "alumnos")
data class AlumnoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val grupo: String
)

@Entity(
    tableName = "evaluaciones",
    foreignKeys = [
        ForeignKey(entity = AlumnoEntity::class, parentColumns = ["id"], childColumns = ["alumnoId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = RubricaEntity::class, parentColumns = ["id"], childColumns = ["rubricaId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("alumnoId"), Index("rubricaId")]
)
data class EvaluacionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val alumnoId: Long,
    val rubricaId: Long,
    val puntajeTotal: Int,
    val puntajeMaximo: Int,
    val nota: Double,
    val retroalimentacion: String,
    val fotoPath: String?,
    val fecha: Long,
    /** false = registrada solo en el teléfono (offline). Se usará en la futura consolidación vía API. */
    val sincronizada: Boolean = false
)

@Entity(
    tableName = "detalles_evaluacion",
    foreignKeys = [
        ForeignKey(entity = EvaluacionEntity::class, parentColumns = ["id"], childColumns = ["evaluacionId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = CriterioEntity::class, parentColumns = ["id"], childColumns = ["criterioId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("evaluacionId"), Index("criterioId")]
)
data class DetalleEvaluacionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val evaluacionId: Long,
    val criterioId: Long,
    val puntaje: Int
)
