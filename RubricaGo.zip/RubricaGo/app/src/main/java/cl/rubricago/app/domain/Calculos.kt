package cl.rubricago.app.domain

import cl.rubricago.app.data.local.AlumnoEntity
import cl.rubricago.app.data.local.EvaluacionEntity
import kotlin.math.round

data class ResumenGrupo(
    val grupo: String,
    val totalAlumnos: Int,
    val evaluacionesHechas: Int,
    val evaluacionesEsperadas: Int,
    val promedio: Double?
) {
    val avance: Float get() = if (evaluacionesEsperadas == 0) 0f else evaluacionesHechas.toFloat() / evaluacionesEsperadas
}

object Calculos {
    /** Nota 1.0–7.0 con 60% de exigencia para el 4.0. */
    fun calcularNota(puntaje: Int, maximo: Int, exigencia: Double = 0.6): Double {
        if (maximo <= 0) return 1.0
        val pct = (puntaje.toDouble() / maximo).coerceIn(0.0, 1.0)
        val nota = if (pct >= exigencia) 4.0 + 3.0 * (pct - exigencia) / (1.0 - exigencia)
        else 1.0 + 3.0 * pct / exigencia
        return (round(nota * 10) / 10.0).coerceIn(1.0, 7.0)
    }

    fun nivelDesempeno(nota: Double): String = when {
        nota >= 6.0 -> "Destacado"
        nota >= 4.0 -> "Aprobado"
        else -> "Insuficiente"
    }

    fun resumenPorGrupo(alumnos: List<AlumnoEntity>, evaluaciones: List<EvaluacionEntity>, totalRubricas: Int): List<ResumenGrupo> =
        alumnos.groupBy { it.grupo }.map { (grupo, integrantes) ->
            val ids = integrantes.map { it.id }.toSet()
            val evs = evaluaciones.filter { it.alumnoId in ids }
            ResumenGrupo(
                grupo = grupo,
                totalAlumnos = integrantes.size,
                evaluacionesHechas = evs.size,
                evaluacionesEsperadas = integrantes.size * totalRubricas,
                promedio = if (evs.isEmpty()) null else evs.map { it.nota }.average()
            )
        }.sortedBy { it.grupo }
}
