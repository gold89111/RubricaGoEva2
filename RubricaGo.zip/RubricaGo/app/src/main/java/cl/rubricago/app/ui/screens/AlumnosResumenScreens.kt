package cl.rubricago.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cl.rubricago.app.data.local.AlumnoEntity
import cl.rubricago.app.recursos.Haptica
import cl.rubricago.app.ui.components.BarraProgreso
import cl.rubricago.app.ui.components.BotonPrincipal
import cl.rubricago.app.ui.components.CampoTexto
import cl.rubricago.app.ui.components.EstadoVacio
import cl.rubricago.app.ui.theme.colorNota
import cl.rubricago.app.utils.formatoNota
import cl.rubricago.app.viewmodel.AlumnoFormViewModel
import cl.rubricago.app.viewmodel.AlumnosViewModel
import cl.rubricago.app.viewmodel.ResumenViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlumnosScreen(vm: AlumnosViewModel, onNuevo: () -> Unit) {
    val alumnos by vm.alumnos.collectAsStateWithLifecycle()
    var aEliminar by remember { mutableStateOf<AlumnoEntity?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Alumnos (datos ficticios)") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onNuevo) { Icon(Icons.Filled.Add, contentDescription = "Agregar alumno") }
        }
    ) { padding ->
        if (alumnos.isEmpty()) {
            EstadoVacio(Icons.Filled.Group, "Aún no hay alumnos. Toca + para agregar.", Modifier.padding(padding))
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(alumnos, key = { it.id }) { a ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Person, contentDescription = null)
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(a.nombre, style = MaterialTheme.typography.titleMedium)
                                Text("Grupo ${a.grupo}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { aEliminar = a }) { Icon(Icons.Filled.Delete, contentDescription = "Eliminar ${a.nombre}") }
                        }
                    }
                }
            }
        }
    }

    aEliminar?.let { alumno ->
        AlertDialog(
            onDismissRequest = { aEliminar = null },
            title = { Text("Eliminar alumno") },
            text = { Text("Se eliminará ${alumno.nombre} y sus evaluaciones. ¿Continuar?") },
            confirmButton = { TextButton(onClick = { vm.eliminar(alumno); aEliminar = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { aEliminar = null }) { Text("Cancelar") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlumnoFormScreen(vm: AlumnoFormViewModel, onVolver: () -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(ui.exito) {
        if (ui.exito) {
            Haptica.exito(context)
            onVolver()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nuevo alumno") },
                navigationIcon = { IconButton(onClick = onVolver) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Usa nombres ficticios (ej: Alumno 07). No ingreses datos reales.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            CampoTexto(ui.nombre, vm::onNombreChange, "Nombre ficticio", Icons.Filled.Person, error = ui.nombreError)
            CampoTexto(ui.grupo, vm::onGrupoChange, "Grupo / sección", Icons.Filled.Tag, error = ui.grupoError, ayuda = "Ej: A, B, C2", imeAction = ImeAction.Done)
            Spacer(Modifier.height(8.dp))
            BotonPrincipal("Guardar alumno", onClick = vm::guardar)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResumenScreen(vm: ResumenViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()

    Scaffold(topBar = { TopAppBar(title = { Text("Resumen por grupo") }) }) { padding ->
        if (ui.grupos.isEmpty()) {
            EstadoVacio(Icons.Filled.BarChart, "Sin datos todavía.", Modifier.padding(padding))
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    AnimatedVisibility(visible = ui.pendientesSync > 0) {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer), modifier = Modifier.fillMaxWidth()) {
                            Text("${ui.pendientesSync} evaluación(es) sin sincronizar (modo offline)", modifier = Modifier.padding(12.dp))
                        }
                    }
                }
                items(ui.grupos, key = { it.grupo }) { g ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Grupo ${g.grupo}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                if (g.promedio != null) {
                                    Text("Prom. ${g.promedio.formatoNota()}", style = MaterialTheme.typography.titleMedium, color = colorNota(g.promedio), fontWeight = FontWeight.Bold)
                                } else {
                                    Text("Sin notas", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline)
                                }
                            }
                            BarraProgreso(g.avance)
                            Text(
                                "${g.evaluacionesHechas} de ${g.evaluacionesEsperadas} evaluaciones · ${g.totalAlumnos} alumnos",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}
