package cl.rubricago.app.recursos

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/** Recurso nativo 1: cámara (foto de evidencia). Las fotos quedan en el almacenamiento privado de la app. */
object Camara {
    fun crearArchivo(context: Context): File {
        val dir = File(context.filesDir, "evidencias").apply { mkdirs() }
        return File(dir, "evidencia_${System.currentTimeMillis()}.jpg")
    }

    fun uriPara(context: Context, archivo: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", archivo)
}
