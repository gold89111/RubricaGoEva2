package cl.rubricago.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cl.rubricago.app.SessionManager
import cl.rubricago.app.data.repository.RubricaRepository
import cl.rubricago.app.domain.Validators
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val usuario: String = "",
    val password: String = "",
    val usuarioError: String? = null,
    val passwordError: String? = null,
    val cargando: Boolean = false,
    val errorGeneral: String? = null,
    val exito: Boolean = false
)

class LoginViewModel(private val repo: RubricaRepository, private val session: SessionManager) : ViewModel() {
    private val _ui = MutableStateFlow(LoginUiState())
    val ui: StateFlow<LoginUiState> = _ui.asStateFlow()

    fun onUsuarioChange(v: String) = _ui.update { it.copy(usuario = v, usuarioError = Validators.validarUsuario(v), errorGeneral = null) }
    fun onPasswordChange(v: String) = _ui.update { it.copy(password = v, passwordError = Validators.validarPassword(v), errorGeneral = null) }

    fun onLogin() {
        val s = _ui.value
        val eU = Validators.validarUsuario(s.usuario)
        val eP = Validators.validarPassword(s.password)
        if (eU != null || eP != null) {
            _ui.update { it.copy(usuarioError = eU, passwordError = eP) }
            return
        }
        viewModelScope.launch {
            _ui.update { it.copy(cargando = true, errorGeneral = null) }
            val usuario = repo.autenticar(s.usuario, s.password)
            if (usuario == null) {
                _ui.update { it.copy(cargando = false, errorGeneral = "Usuario o contraseña incorrectos") }
            } else {
                session.iniciar(usuario.nombre)
                _ui.update { it.copy(cargando = false, exito = true) }
            }
        }
    }
}

data class RegisterUiState(
    val nombre: String = "",
    val usuario: String = "",
    val password: String = "",
    val confirmacion: String = "",
    val nombreError: String? = null,
    val usuarioError: String? = null,
    val passwordError: String? = null,
    val confirmacionError: String? = null,
    val cargando: Boolean = false,
    val errorGeneral: String? = null,
    val exito: Boolean = false
)

class RegisterViewModel(private val repo: RubricaRepository) : ViewModel() {
    private val _ui = MutableStateFlow(RegisterUiState())
    val ui: StateFlow<RegisterUiState> = _ui.asStateFlow()

    fun onNombreChange(v: String) = _ui.update { it.copy(nombre = v, nombreError = Validators.validarNombre(v), errorGeneral = null) }
    fun onUsuarioChange(v: String) = _ui.update { it.copy(usuario = v, usuarioError = Validators.validarUsuario(v), errorGeneral = null) }
    fun onPasswordChange(v: String) = _ui.update {
        it.copy(
            password = v, passwordError = Validators.validarPassword(v),
            confirmacionError = if (it.confirmacion.isEmpty()) null else Validators.validarConfirmacion(v, it.confirmacion)
        )
    }
    fun onConfirmacionChange(v: String) = _ui.update { it.copy(confirmacion = v, confirmacionError = Validators.validarConfirmacion(it.password, v)) }

    fun onRegistrar() {
        val s = _ui.value
        val eN = Validators.validarNombre(s.nombre)
        val eU = Validators.validarUsuario(s.usuario)
        val eP = Validators.validarPassword(s.password)
        val eC = Validators.validarConfirmacion(s.password, s.confirmacion)
        if (listOf(eN, eU, eP, eC).any { it != null }) {
            _ui.update { it.copy(nombreError = eN, usuarioError = eU, passwordError = eP, confirmacionError = eC) }
            return
        }
        viewModelScope.launch {
            _ui.update { it.copy(cargando = true, errorGeneral = null) }
            val creado = repo.registrarUsuario(s.nombre, s.usuario, s.password)
            if (creado) _ui.update { it.copy(cargando = false, exito = true) }
            else _ui.update { it.copy(cargando = false, usuarioError = "Ese usuario ya existe", errorGeneral = "No se pudo crear la cuenta") }
        }
    }
}
